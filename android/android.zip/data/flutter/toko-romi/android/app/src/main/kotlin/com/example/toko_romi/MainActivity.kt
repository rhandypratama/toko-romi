package com.example.toko_romi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
